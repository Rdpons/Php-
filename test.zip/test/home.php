<?php
session_start();
include("config.php");

if(!isset($_SESSION['firstName'])){
    header("location: login.php");
    exit;
}
$firstName = $_SESSION['firstName'];
$lastName = $_SESSION['lastName'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
        *{  margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        header{
            background-color: #f0f0f0;
            width: 50%;
            height: 100%;

        }
        .list-group-nav{
            list-style: none;
            margin-right : 0;
            padding: 10px;
            display: block;
            justify-content: right;
            gap: 10px;
        }
       .list-group {
            list-style: none;
            margin-top: 20px;
            padding: 0;
            background-color: #f0f0f0;
            border: 1px solid #ccc
        }
        .list-group-item{
            border-bottom: 1px solid #ddd;
            padding: 10px;
        }
    </style>
</head>
<body>
    <header>
    <nav>
        <ul class="list-group-nav">
        <li>Home</li>
        <li>About</li>
        <li>Contact</li>
        </ul>
    </nav>
    </header>
    <h1>Welcome, <?php echo $_SESSION['firstName'];?></h1>

    <ul class="list-group">
    <?php
        $query = "SELECT * FROM `students`";
        $result = mysqli_query($conn,$query);

        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                echo "<li class='list-group-item'>". $row["firstName"]."</li>";
                echo "<li class='list-group-item'>". $row["lastName"]."</li>";
                echo "<li class='list-group-item'>". $row["gender"]."</li>";
                echo "<li class='list-group-item'>". $row["contactNo"]."</li>";
            }
        }else{
                echo "0 results";
        }
        $conn->close();
        ?>
    </ul>
</body>
</html>