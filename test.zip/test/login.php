<?php
session_start();
include("config.php");

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM `user` WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn,$query);

    if($result && mysqli_num_rows($result) == 1){
        $user = mysqli_fetch_assoc($result);

        $_SESSION['firstName'] = $user['firstName'];
        $_SESSION['lastName'] = $user['lastName'];
        header("location: home.php");
        exit;
    }else{
        $error = "<span style='color:red;'>Invalid Email or Password</span>";
        echo $error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        *{
            font-family: sans-serif;
            box-sizing: border-box;
        }
        body{
            background-color: peachpuff;
        }
        form{
            display: flex;
            justify-content: space-around;
            gap: 12;
        }
        input[type=email]{
            margin: 0;
            padding: 10px;
            border: 1px solid gray;
            outline: none;
            border-radius: 10px;
            width: 40%;
            height: 50px;
        }
    </style>
</head>
<body>
    <form action="" method="POST">
        <input type="email" name="email" placeholder="Enter your Email">
        <input type="password" name="password" placeholder="Enter your Password">
        <input type="submit" name="submit" value="Login">
    </form>
</body>
</html>