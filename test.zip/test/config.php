<?php
$host = "localhost";
$user = "root";
$pass = "";
$database = "hehe";

$conn = new mysqli($host, $user, $pass, $database);
if($conn->connect_error){
    echo ("Connection Faile" .$conn->connect_error);
}
?>