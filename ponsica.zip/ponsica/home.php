<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CCS SIT-IN MONITORING SYSTEM</title>
    <style>
        :root {
            --black: #2c2b30;
            --gray: #4f4f51;
            --white: #d6d6d6;
            --pink: #f2c4ce;
            --orange: #f58f7c;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: var(--white);
            color: var(--black);
        }

        .container {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: var(--black);
            color: var(--white);
            padding: 20px;
            text-align: center;
        }

        .content {
            flex: 1;
            display: flex;
        }

        .burger-menu {
            width: 250px;
            background-color: var(--gray);
            padding: 20px;
            box-sizing: border-box;
            transition: width 0.5s;
        }

        .burger-menu.minimized {
            width: 50px;
        }

        .burger-icon {
            font-size: 24px;
            cursor: pointer;
            color: var(--white);
        }

        .menu {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .menu li {
            margin-bottom: 10px;
        }

        .menu a {
            color: var(--white);
            text-decoration: none;
        }

        .dashboard-content {
            flex: 1;
            padding: 20px;
        }

        footer {
            background-color: var(--black);
            color: var(--black);
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>CCS SIT-IN MONITORING SYSTEM</h1>
        </header>
        <div class="content">
            <div class="burger-menu" id="burger-menu">
                <div class="dashboard-toggle" onclick="toggleMenu()">
                    <span class="burger-icon">&#9776;</span>
                </div>
                <ul class="menu">
                    <li><a href="#">Your Account</a></li>
                    <li><a href="#">Edit Record Sit-in</a></li>
                    <li><a href="#">View Remaining Session</a></li>
                    <li><a href="#">Make Reservation</a></li>
                    <li><a href="#">Login</a></li>
                    <li><a href="#">Logout</a></li>
                </ul>
            </div>
            <div class="dashboard-content" id="dashboard-content">
                <h2>Welcome CCS Students!</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis magna in dolor ultricies rutrum. Vivamus mollis bibendum felis, et fringilla libero sollicitudin at. Nulla facilisi. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Integer interdum dictum nisi, nec posuere est rutrum at.</p>
            </div>
        </div>
        <footer>
            &copy; 2024 CCS SIT-IN MONITORING SYSTEM. All Rights Reserved.
        </footer>
    </div>

    <script>
        function toggleMenu() {
            var burgerMenu = document.getElementById("burger-menu");

            if (burgerMenu.classList.contains("minimized")) {
                burgerMenu.classList.remove("minimized");
            } else {
                burgerMenu.classList.add("minimized");
            }
        }
    </script>
</body>
</html>
