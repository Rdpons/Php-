<?php
session_start();
header("Location: home.php");
exit();
?>
