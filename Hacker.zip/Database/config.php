<?php
$conn = mysqli_connect('localhost','root','','ponsica') or die('connection failed');
?>