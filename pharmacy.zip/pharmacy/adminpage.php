<?php
include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmacy</title>
    <link rel="stylesheet" href="adminpagestyle.css">
</head>
<body>
	<div class="header">
		<h1>Pharmacy</h1>
	</div>
	<hr>
	<div class="buttons">
		<!-- Buttons for each option -->
		<a href="staff.php?option=STAFF" class="option-button">STAFF</a>
		<a href="blank_page.php?option=MEDICINE" class="option-button">MEDICINE</a>
		<a href="blank_page.php?option=RETURNED_MEDICINE" class="option-button">RETURNED MEDICINE</a>
		<a href="blank_page.php?option=COMPANY" class="option-button">COMPANY</a>
		<a href="blank_page.php?option=RECEIPT" class="option-button">RECEIPT</a>
		<a href="blank_page.php?option=SALES" class="option-button">SALES</a>
		<a href="blank_page.php?option=BILL" class="option-button">BILL</a>
	</div>
</body>
</html>
