<?php
include 'connection.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Sanitize form inputs to prevent SQL injection
    $staff_name = mysqli_real_escape_string($conn, $_POST['staff_name']);
    $staff_role = mysqli_real_escape_string($conn, $_POST['staff_role']);

    // Insert the new staff into the database
    $sql = "INSERT INTO STAFF (STAFF_NAME, STAFF_ROLE) VALUES ('$staff_name', '$staff_role')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Staff added successfully!');</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
    }

    // Redirect back to the original page after form submission
    echo '<script>window.location.href = "staff.php";</script>';
    exit(); // Ensure that script execution stops after redirection
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Management</title>
    <link rel="stylesheet" href="staffstyle.css">
</head>
<body>
	<div class="header">
		<a href="adminpage.php"><button class="return-button" type="button">Return</button></a>
		<h1>Staff Management</h1>
	</div>
	<hr>
    <?php
    // READ operation
    $sql = "SELECT * FROM STAFF";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<div class='staff-list-container'>";
		echo "<table class='staff-list-table'>";
		echo "<tr><th class='staff-list-header'>Staff ID</th><th class='staff-list-header'>Staff Name</th><th class='staff-list-header'>Staff Role</th></tr>";
		while ($row = $result->fetch_assoc()) {
			echo "<tr class='staff-list-row'>";
			echo "<td class='staff-list-cell'>".$row['STAFF_ID']."</td>";
			echo "<td class='staff-list-cell'>".$row['STAFF_NAME']."</td>";
			echo "<td class='staff-list-cell'>".$row['STAFF_ROLE']."</td>";
			echo "</tr>";
		}
		echo "</table>";
		echo "</div>";
	}
    // Close connection
    $conn->close();
    ?>

    <!-- Button to open the add staff form -->
    <button class="add-button" onclick="openAddForm()">Add Staff</button>

    <!-- Button to open the delete staff form -->
    <a href="staffdelete.php"><button class="delete-button" type="button">Delete Staff</button></a>
	
	<div class="add-staff-form">
    <!-- Add Staff Form -->
		<div class="overlay" id="addOverlay"></div> <!-- Add overlay for Add Staff Form -->
		<div class="form-popup" id="addStaffForm">
			<form class="form-container" method="post">
				<h1>Add Staff</h1>
				<label for="staff_name"><b>Name</b></label>
				<input type="text" placeholder="Enter Staff Name" name="staff_name" required>

				<label for="staff_role"><b>Role</b></label>
				<input type="text" placeholder="Enter Staff Role" name="staff_role" required>

				<button type="submit" class="btn" name="submit">Add</button>
				<button type="button" class="btn cancel" onclick="closeAddForm()">Close</button>
			</form>
		</div>
    </div>

    <script>
        // Function to open the add staff form
        function openAddForm() {
            document.getElementById("addStaffForm").style.display = "block";
            document.getElementById("addOverlay").style.display = "block";
        }
		
		// Function to close the add staff form
        function closeAddForm() {
            document.getElementById("addStaffForm").style.display = "none";
            document.getElementById("addOverlay").style.display = "none";
        }
    </script>
</body>
</html>