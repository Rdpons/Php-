-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2024 at 02:46 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `BILL_ID` int(11) NOT NULL,
  `BILL_DATE` date DEFAULT NULL,
  `BILL_TOTAL` decimal(10,2) DEFAULT NULL,
  `STAFF_ID` int(11) DEFAULT NULL,
  `MEDICINE_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`BILL_ID`, `BILL_DATE`, `BILL_TOTAL`, `STAFF_ID`, `MEDICINE_ID`) VALUES
(1, '2008-11-11', 180.00, 2, 1),
(2, '2009-12-13', 200.00, 1, 2),
(3, '2010-02-13', 200.00, 4, 3),
(4, '2011-03-13', 200.00, 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `COMPANY_ID` int(11) NOT NULL,
  `COMPANY_NAME` varchar(50) DEFAULT NULL,
  `COMPANY_DESC` varchar(255) DEFAULT NULL,
  `MEDICINE_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`COMPANY_ID`, `COMPANY_NAME`, `COMPANY_DESC`, `MEDICINE_ID`) VALUES
(1, 'UNILAB, Inc', 'Working towards a healthier Philippines, one quality medicine at a time.', 1),
(2, 'Rose Pharmacy', 'With over 402 branches in strategic locations all over the country, Rose Pharmacy is recognized as one of the Philippines  top pharmaceutical retailers, providing customers with easy access to quality health and beauty products.', 2);

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `MEDICINE_ID` int(11) NOT NULL,
  `MEDICINE_NAME` varchar(50) DEFAULT NULL,
  `MEDICINE_QNTY` int(11) DEFAULT NULL,
  `MEDICINE_PRICE` decimal(10,2) DEFAULT NULL,
  `MEDICINE_DESC` varchar(2500) DEFAULT NULL,
  `MEDICINE_LOCATION` varchar(50) DEFAULT NULL,
  `COMPANY_ID` int(11) DEFAULT NULL,
  `MEDICINE_IMAGE_PATH` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`MEDICINE_ID`, `MEDICINE_NAME`, `MEDICINE_QNTY`, `MEDICINE_PRICE`, `MEDICINE_DESC`, `MEDICINE_LOCATION`, `COMPANY_ID`, `MEDICINE_IMAGE_PATH`) VALUES
(1, 'Poten Cee Na 562.5mg Capsule', 100, 140.00, '500 mg Ascorbic Acid (As Sodium Ascorbate 562.5 mg) Capsule Ideal for people who have sensitive stomachs or hyperacidity. Dosage: For regular supplementation: Take 1 capsule a day. For increased resistance against colds and flu: Take 2 to 3 capsules a day or as prescribed by a healthcare professional.\r\n\r\nHighlights/USP :\r\n\r\n- To prevent hyperacidity\r\n\r\n- Helps promote natural collagen production in the body.\r\n\r\n- Boost Immunity\r\n\r\nIndications:\r\n\r\nIncreases the immunity of the body and hastens wound healing , prevents common colds and flu and improves the circulation of the heart and blood vessels.\r\n\r\nPlace Of Origin\r\nPhilippines\r\n\r\nProduct Usage\r\n1-2 tablet/day\r\n\r\nIngredients\r\n500mg of Vitamin C / 562.50mg of Sodium Ascorbate\r\n\r\nWarnings\r\nShould be given with care to patients with hyperxaluria', 'Rack 3, Storage 1', NULL, './images/med1.png'),
(2, 'Poten-Cee Forte 1g Tablet 8+1', 100, 165.00, 'Poten-Cee Forte 8+1 helps promote natural collagen production in the body. It increases the immunity of the body and hastens wound healing, prevents common colds and flu and improves the circulation of the heart and blood vessels.\r\n\r\n- It contains 1000 mg of Ascorbic Acid (vitamin C) in 8-hour time release for whole day vitamin C protection\r\n- Poten-Cee Forte is ideal for people who works in a toxic environment and who have busy working schedule.\r\n- Vitamin C helps boost immunity and is essential in collagen production for healthy skin and hair\r\n\r\nDosage: Take one (1) tablet daily as a dietary supplement or as prescribed by the physician\r\n\r\nPlace Of Origin\r\nPhilippines\r\n\r\nProduct Usage\r\nFor regular vitamin C supplement, 1 tablet daily\r\nFor increased resistance against colds and flu\r\n\r\nIngredients\r\n1000mg Ascorbic Acid\r\n\r\nIngredients\r\n1000mg Ascorbic Acid', 'Rack 3, Storage 1', NULL, './images/med2.png'),
(3, 'Fern-C 568.18mg', 100, 292.50, 'Prevention &, treatment of vit C deficiency. Helps increase body resistance to stress, common colds, as well as viral &, other types of infections. Helps meet the augmented vit C requirements in pregnant or lactating women, alcoholics &, smokers, athletes, the elderly, those w/ infectious &, chronic illnesses, &, those undergoing operation &, dental surgery. Essential for stimulating the production of collagen, which covers &, protects mucosal linings &, tissues necessary in maintaining all organs, including the heart &, blood vessels. Hastens wound healing &, increases body resistance to infectious diseases while keeping healthy gums, teeth, bones &, other connective tissues. As a potent antioxidant, effectively fights free radicals &, its harmful effects.\r\n\r\nPlace Of Origin\r\nPhilippines\r\n\r\nProduct Usage\r\nFor daily maintenance, take 1-2 capsule/s.\r\nFor cold symptoms take 3-4 capsules daily.\r\nMay be given as is or dissolve the capsule contents in fruit juices, water or cold beverages of choice.\r\n\r\n\r\nIngredients\r\nEach capsule contains: Sodium Ascorbate 568.18 mg (equivalent to Ascorbic Acid 500 mg).', 'Rack 3, Storage 1', NULL, './images/med3.png'),
(4, 'Enervon C Flex Tablet', 100, 72.50, 'Nutritional supplement to help promote increased energy & enhance the immune system. Treatment of vit B-complex & vit C deficiencies.\r\nPlace Of Origin\r\nPhilippines\r\n\r\nProduct Usage\r\nOrally, one tablet daily Or, as directed by a doctor.\r\nMissed Dose\r\n\r\n\r\nIngredients\r\nPer tablet contains\r\n\r\nWarnings\r\nSpecial Precautions: Do not take more than the recommended dose..', 'Rack 1, Storage 1', NULL, './images/med4.png');

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE `receipt` (
  `RECEIPT_ID` int(11) NOT NULL,
  `RECEIPT_DATE` date DEFAULT NULL,
  `SALES_ID` int(11) DEFAULT NULL,
  `BILL_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `returnmedicine`
--

CREATE TABLE `returnmedicine` (
  `RETURN_ID` int(11) NOT NULL,
  `RETURN_DATE` date DEFAULT NULL,
  `RETURN_QNTY` int(11) DEFAULT NULL,
  `MEDICINE_ID` int(11) DEFAULT NULL,
  `STAFF_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `returnmedicine`
--

INSERT INTO `returnmedicine` (`RETURN_ID`, `RETURN_DATE`, `RETURN_QNTY`, `MEDICINE_ID`, `STAFF_ID`) VALUES
(1, '2008-03-24', 5, 2, 2),
(2, '2009-01-17', 6, 2, 3),
(3, '2009-01-17', 4, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `SALES_ID` int(11) NOT NULL,
  `SALES_DATE` date DEFAULT NULL,
  `STAFF_ID` int(11) DEFAULT NULL,
  `BILL_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `STAFF_ID` int(11) NOT NULL,
  `STAFF_NAME` varchar(50) DEFAULT NULL,
  `STAFF_ROLE` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`STAFF_ID`, `STAFF_NAME`, `STAFF_ROLE`) VALUES
(1, 'Emily Johnson', 'Pharmacist'),
(2, 'Daniel Lee', 'Pharmacist'),
(3, 'Sarah Martinez', 'Admin'),
(4, 'Michael Brown', 'Pharmacist'),
(30, 'Jay Lionheart', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`BILL_ID`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`COMPANY_ID`),
  ADD KEY `FK_MEDICINE_ID_COMPANY` (`MEDICINE_ID`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`MEDICINE_ID`),
  ADD KEY `FK_COMPANY_ID` (`COMPANY_ID`);

--
-- Indexes for table `receipt`
--
ALTER TABLE `receipt`
  ADD PRIMARY KEY (`RECEIPT_ID`),
  ADD KEY `FK_BILL_ID_RECEIPT` (`BILL_ID`);

--
-- Indexes for table `returnmedicine`
--
ALTER TABLE `returnmedicine`
  ADD PRIMARY KEY (`RETURN_ID`),
  ADD KEY `FK_MEDICINE_ID` (`MEDICINE_ID`),
  ADD KEY `FK_STAFF_ID` (`STAFF_ID`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`SALES_ID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`STAFF_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `BILL_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `COMPANY_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `MEDICINE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `receipt`
--
ALTER TABLE `receipt`
  MODIFY `RECEIPT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `returnmedicine`
--
ALTER TABLE `returnmedicine`
  MODIFY `RETURN_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `SALES_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `STAFF_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `company`
--
ALTER TABLE `company`
  ADD CONSTRAINT `FK_MEDICINE_ID_COMPANY` FOREIGN KEY (`MEDICINE_ID`) REFERENCES `medicine` (`MEDICINE_ID`);

--
-- Constraints for table `medicine`
--
ALTER TABLE `medicine`
  ADD CONSTRAINT `FK_COMPANY_ID` FOREIGN KEY (`COMPANY_ID`) REFERENCES `company` (`COMPANY_ID`);

--
-- Constraints for table `receipt`
--
ALTER TABLE `receipt`
  ADD CONSTRAINT `FK_BILL_ID_RECEIPT` FOREIGN KEY (`BILL_ID`) REFERENCES `bill` (`BILL_ID`);

--
-- Constraints for table `returnmedicine`
--
ALTER TABLE `returnmedicine`
  ADD CONSTRAINT `FK_MEDICINE_ID` FOREIGN KEY (`MEDICINE_ID`) REFERENCES `medicine` (`MEDICINE_ID`),
  ADD CONSTRAINT `FK_STAFF_ID` FOREIGN KEY (`STAFF_ID`) REFERENCES `staff` (`STAFF_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
