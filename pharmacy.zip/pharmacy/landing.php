<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap' rel='stylesheet'>
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="landing.css">
    <title>IwantMed</title>
</head>
<body>
    <header>
        <nav>
            <a href="#iwantmed" class="logo">IwantMed</a>
            <ul class="nav-links">
                <li><a href="#medicines">Medicines</a></li>
                <li><a href="#contact">Contact</a></li>
                <a href="login.php" class="button">Login</a>
            </ul>
            <i class="burger-menu bx bx-menu"></i>
        </nav>
    </header>
    <section class="hero" id="iwantmed">
        <h1>Welcome to IwantMed</h1>
        <p>Get your prescriptions filled with ease.</p>
        <a href="#" class="button">Learn More</a>
    </section>
    <section class="medicines" id="medicines">
    <h2>Immunity Boosters</h2>
    <ul>
        <li>
            <a href="med_desc.php?id=1">
            <img src="./images/med1.png" alt="Medicine 1">
            <h3>Poten Cee Na 562.5mg Capsule </h3>
            <p>₱140.00</p>
            <button class="add-to-cart">Add to Cart</button>
            </a>
        </li>
        <li>
            <a href="med_desc.php?id=2">
            <img src="./images/med2.png" alt="Medicine 2">
            <h3>Poten-Cee Forte 1g Tablet 8+1</h3>
            <p>₱165.00</p>
            <button class="add-to-cart">Add to Cart</button>
            </a>
        </li>
        <li>
            <a href="med_desc.php?id=3">
            <img src="./images/med3.png" alt="Medicine 2">
            <h3>Fern-C 568.18/mg </h3>
            <p>₱292.50</p>
            <button class="add-to-cart">Add to Cart</button>
            </a>
        </li>
        </ul>
    </section>
    <section class="medicines" id="medicines">
    <h2>Antibiotics</h2>
    <ul>
        <li>
            <img src="./images/med6.png" alt="Medicine 1">
            <h3>Amoxicillin </h3>
            <p>₱161.00</p>
            <button class="add-to-cart">Add to Cart</button>
        </li>
        <li>
            <img src="./images/med7.png" alt="Medicine 2">
            <h3>Doxycycline</h3>
            <p>₱75.75</p>
            <button class="add-to-cart">Add to Cart</button>
        </li>
        <li>
            <img src="./images/med8.png" alt="Medicine 2">
            <h3>Cephalexin </h3>
            <p>₱50.75</p>
            <button class="add-to-cart">Add to Cart</button>
        </li>
        <li>
            <img src="./images/med9.png" alt="Medicine 2">
            <h3>Ciprofloxacin</h3>
            <p>₱24.00</p>
            <button class="add-to-cart">Add to Cart</button>
        </li>
        <li>
            <img src="./images/med10.png" alt="Medicine 2">
            <h3>Clindamycin</h3>
            <p>₱124.75</p>
            <button class="add-to-cart">Add to Cart</button>
        </li>
        </ul>
    </section>

    <footer id="contact">
        <p>Contact us at praised.capt006@gmail.com</p>
    </footer>

    <script>
        const burgerMenu = document.querySelector('.burger-menu');
        const navLinks = document.querySelector('.nav-links');

        burgerMenu.addEventListener('click', () => {
            navLinks.classList.toggle('show');
        });
    </script>
</body>
</html>
