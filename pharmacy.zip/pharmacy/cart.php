 <?php  
session_start();
include('connection.php');
if (!isset($_SESSION['user_id'])) {
    echo "Please log in to view your cart.";
    exit; 
}
$userId = $_SESSION['user_id'];
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}
$stmt = $mysqli->prepare("SELECT medicine.MEDICINE_ID, medicine.MEDICINE_NAME, medicine.MEDICINE_PRICE, bill.BILL_TOTAL FROM medicine JOIN bill ON medicine.MEDICINE_ID = bill.MEDICINE_ID WHERE bill.STAFF_ID = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$total = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <a href="#iwantmed" class="logo">IwantMed</a>
            <ul class="nav-links">
                <li><a href="#medicines">Medicines</a></li>
                <li><a href="#contact">Contact</a></li>
                <a href="login.php" class="button">Login</a>
            </ul>
            <i class="burger-menu bx bx-menu"></i>
        </nav>
    </header>
    <h1>Your Cart</h1>
    <table>
        <tr>
            <th>Medicine Name</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['MEDICINE_NAME']); ?></td>
                <td>₱<?php echo htmlspecialchars($row['MEDICINE_PRICE']); ?></td>
                <td>1</td> 
                <td>₱<?php echo htmlspecialchars($row['BILL_TOTAL']); ?></td>
            </tr>
            <?php $total += $row['BILL_TOTAL']; ?>
        <?php endwhile; ?>
    </table>
    <p>Total: ₱<?php echo htmlspecialchars($total); ?></p>
    <a href="checkout.php">Proceed to Checkout</a>
</body>
</html>
