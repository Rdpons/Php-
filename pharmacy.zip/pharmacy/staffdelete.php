<?php
include 'connection.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['staff_id'])) {
    // Sanitize the staff ID to prevent SQL injection
    $staff_id = mysqli_real_escape_string($conn, $_POST['staff_id']);

    // Construct the SQL query to delete the staff record
    $sql = "DELETE FROM STAFF WHERE STAFF_ID = '$staff_id'";

    // Execute the SQL query
    if ($conn->query($sql) === TRUE) {
        // Deletion successful
        // Redirect to prevent form resubmission
        header("Location: staffdelete.php");
        exit(); // Ensure script execution stops after redirection
    } else {
        // Error in deletion
        echo "<script>alert('Error deleting staff: " . $conn->error . "');</script>";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Staff</title>
    <link rel="stylesheet" href="staffdeletestyle.css">
</head>
<body>
	<div class="header">
		<a href="staff.php"><button class="return-button" type="button">Return</button></a>
		<h1>Delete Staff</h1>
	</div>
	<hr>
	<div class="form-table">
		<form class="form-container" method="post">
			<?php
			// Include the database connection
			include 'connection.php';

			// READ operation to fetch staff data
			$sql = "SELECT * FROM STAFF";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				echo "<div class='staff-list-container'>";
				echo "<table class='staff-list-table'>";
				echo "<tr><th class='staff-list-header'>Staff ID</th><th class='staff-list-header'>Staff Name</th><th class='staff-list-header'>Staff Role</th><th class='staff-list-header'>Action</th></tr>";
				while ($row = $result->fetch_assoc()) {
					echo "<td class='staff-list-cell'>".$row['STAFF_ID']."</td>";
					echo "<td class='staff-list-cell'>".$row['STAFF_NAME']."</td>";
					echo "<td class='staff-list-cell'>".$row['STAFF_ROLE']."</td>";
					echo "<td class='staff-list-cell'>";
					echo "<input type='hidden' name='staff_id' value='".$row['STAFF_ID']."'>";
					echo "<input class='delete-button' type='submit' value='Delete'>"; // Submit button
					echo "</td>";
					echo "</tr>";
				}
				echo "</table>";
				echo "</div>";
			} else {
				echo "No staff members found.";
			}

			// Close the database connection
			$conn->close();
			?>
		</form>
	</div>
</body>
</html>
