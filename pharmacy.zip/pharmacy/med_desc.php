<?php
include('connection.php');

$medicineId = isset($_GET['id']) ? $_GET['id'] : null;

$stmt = $mysqli->prepare("SELECT * FROM medicine WHERE MEDICINE_ID = ?");
$stmt->bind_param("i", $medicineId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $medicine = $result->fetch_assoc();
} else {
    echo "Medicine not found.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap' rel='stylesheet'>
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="landing.css">
    <title>IwantMed</title>
    <style>
        :root {
            --poppins: 'Poppins', sans-serif;
            --white: #f2f2f2;
            --black: #000;
            --peach: #F58F7C;
            --lightOrange: #FEEAC4;
            --darkOrange: #F1BB53;
        }
        body {
            font-family: var(--poppins);
            margin: 0;
            padding: 0;
            background-color: #fff;
        }
        header {
            background-color: var(--white);
            padding: 20px 0;
            text-align: center;
        }
        .logo {
            color: var(--black);
            text-decoration: none;
            font-size: 24px;
            font-weight: bold;
        }
        section{
            background-color: var(--white);
        }
        .nav-links {
            list-style: none;
            padding: 0;
            display: flex;
            justify-content: space-around;
            align-items: center;
            color: #fff;
            flex-wrap: wrap; 
        }
        .nav-links a {
            color: #fff;
            text-decoration: none;
        }
        .burger-menu {
            display: block; 
            cursor: pointer;
        }
        .hero {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap; 
            padding: 20px;
        }
        .medicine-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 40px 20px;
            margin: 40px auto;
            margin-left: 700px;
            margin-top: -600px;
            max-width: 500px;
            background-color: #fff;
        }
        .medicine-image img {
            background-color: #fff;
            height: auto;
            object-fit: cover;
            border: 1px solid gray;
            margin-right: 560px; 
            margin-top: 100px;
            max-width: 100%; 
        }
        .medicine-details {
            text-align: center;
            margin-top: 20px;
        }
        .medicine-details h2 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 10px;
        }
        .medicine-details p {
            font-size: 16px;
            color: #666;
            margin-bottom: 10px;
        }
        .add-to-cart {
            font-weight: 600;
            text-decoration: none;
            color: #fff;
            padding: 10px 20px;
            background-color: var(--darkOrange);
            border-radius: 10px;
            transition: 0.2s;
            margin-top: -20px;
            border: none;
        }
        .add-to-cart:hover {
            filter: brightness(110%);
            color: var(--black);
            cursor: pointer;
        }
        footer {
            background-color: #F1BB53;
            padding: 20px 0;
            text-align: center;
            color: var(--black);
            margin-top: 40px;
        }
        @media screen and (min-width: 769px) {
            .burger-menu {
                display: none;
            }
        }
        @media screen and (max-width: 768px) {
            .nav-links {
                display: none;
            }
        }
        @media screen and (min-width: 769px) and (max-width: 1024px) {
            .medicine-image img {
                width: 160%;
                height: auto;
            }
        }
        @media screen and (min-width: 1025px) {
            .medicine-image img {
                width: 30%;
                height: auto;
            }
        }
        .justify{
            text-align: justify;
            color:var(--black);
        }
        .med-name{
            font-size: 20px;
            margin-left: -550px;
        }
        .hero{
            background-color: #fff;
        }
        .button {
            font-weight: 600;
            text-decoration: none;
            color: #fff;
            padding: 10px 20px;
            background-color: var(--darkOrange);
            border-radius: 10px;
            transition: 0.2s;
            margin-top: -10px;
        }
        .button:hover {
            filter: brightness(110%);
            color: var(--black);
        }
        .price {
            width: 400px;
            padding: 50px;
            text-align: center;
            margin-top: -250px; 
            margin-left: 250px;
        }
        .price-item {
            font-weight: 600;
            font-size: 16px;
            color: #666; 
            color: var(--black);
            margin-top: 0px;
        }
       
        .quantity-controls {
            display: flex;
            align-items: center;
            margin-top: 10px;
            margin-left: 75px;
        }

        .quantity-decrease,
        .quantity-increase {
            background-color: var(--darkOrange);
            border: 1px solid #F1BB53; 
            border-radius: 5px;
            padding: 5px 10px; 
            font-size: 14px; 
            cursor: pointer;
            margin-left: 10px;
            margin-right: 10px;
            color: #fff;
            gap: 5px; 

        }
        .quantity-decrease:hover,
        .quantity-increase:hover {
            filter: brightness(110%);
            color: var(--black);
        }
        .quantity-input input {
            width: 50px; 
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px; 
            margin-left:1px
        }

        input[type="number"]::-webkit-inner-spin-button,
        input[type="number"]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type="number"] {
            text-align: center;
        }
        @media screen and (max-width: 768px) {
            .medicine-container {
                margin-left: 0;
                margin-top: 0;
                padding: 20px;
            }
            .medicine-image img {
                margin-right: 0;
                margin-top: 20px;
            }
            .med-name {
                margin-left: 0;
            }
            .price {
                width: auto;
                padding: 20px;
                margin-left: 0;
                margin-top: 20px;
            }
            .quantity-controls {
                flex-direction: row;
                margin-left: 50px; 
            }
            .quantity-decrease,
            .quantity-increase{
                gap: 5px;
            }
        }
    </style>
</head>
<body>
    <header id="logo">
        <nav>
            <a href="landing.php" class="logo">IwantMed</a>
            <ul class="nav-links">
                <li><a href="landing.php">Medicines</a></li>
                <li><a href="#contact">Contact</a></li>
                <a href="login.php" class="button">Login</a>
            </ul>
            <i class="burger-menu bx bx-menu"></i>
        </nav>
    </header>
    <section class="hero">
        <div class="medicine-image">
            <?php if (!empty($medicine['MEDICINE_IMAGE_PATH'])): ?>
                <img src="<?php echo htmlspecialchars($medicine['MEDICINE_IMAGE_PATH']); ?>" alt="Medicine Image">
            <?php else: ?>
                <img src="./images/default-medicine.jpg" alt="Placeholder Image">
            <?php endif; ?>
            <h2 class="med-name"><?php echo htmlspecialchars($medicine['MEDICINE_NAME']); ?></h2>
        </div>
        <div class="medicine-container">
            <div class="medicine-details">
                <p class="justify"><?php echo nl2br($medicine['MEDICINE_DESC']); ?></p>
            </div>           
        </div> 
        <div class="price">
    <p class="price-item">Price: ₱<?php echo htmlspecialchars($medicine['MEDICINE_PRICE']); ?></p>
    <p class="price-item">Stock Available: <?php echo htmlspecialchars($medicine['MEDICINE_QNTY']); ?></p>
    <div class="quantity-input">
        <label for="quantity">Quantity:</label>
        <div class="quantity-controls">
            <button type="button" class="quantity-decrease">-</button>
            <input type="number" id="quantity" name="quantity" min="1" placeholder="Enter quantity" value="1">
            <button type="button" class="quantity-increase">+</button>
        </div>
    </div>
    <br>
    <form id="addToCartForm" action="cart.php" method="post">
        <input type="hidden" name="medicine_id" value="<?php echo htmlspecialchars($medicine['MEDICINE_ID']); ?>">
        <input type="hidden" name="medicine_price" value="<?php echo htmlspecialchars($medicine['MEDICINE_PRICE']); ?>">
        <input type="hidden" name="quantity" id="quantity" value="1">
        <button type="submit" class="add-to-cart">Add to Cart</button>
    </form>
</div>
    </section>
    <footer id="contact">
        <p>Contact us at praised.capt006@gmail.com</p>
    </footer>
    <script>
        const burgerMenu = document.querySelector('.burger-menu');
        const navLinks = document.querySelector('.nav-links');

        burgerMenu.addEventListener('click', () => {
            navLinks.classList.toggle('show');
        });
        document.addEventListener('DOMContentLoaded', function() {
            const quantityInput = document.getElementById('quantity');
            const decreaseBtn = document.querySelector('.quantity-decrease');
            const increaseBtn = document.querySelector('.quantity-increase');

            decreaseBtn.addEventListener('click', function() {
                if (quantityInput.value > 1) {
                    quantityInput.value--;
                }
            });

            increaseBtn.addEventListener('click', function() {
                quantityInput.value++;
            });
        });
        document.addEventListener('DOMContentLoaded', function() {
        const addToCartForm = document.getElementById('addToCartForm');
        const addToCartButton = addToCartForm.querySelector('.add-to-cart');

        addToCartButton.addEventListener('click', function(event) {
            event.preventDefault(); 
            addToCartForm.submit(); 
        });
    });
    </script>
</body>
</html>
