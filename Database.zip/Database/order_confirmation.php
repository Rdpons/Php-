<?php
include('config.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        header {
            background-color: #343a40;
            color: #fff;
            padding: 1rem;
            text-align: center;
            width: 100%;
            margin-bottom: 20px;
            font-size: 50px;
        }
		
        .confirmation-container {
            text-align: center;
            margin-top: 50px;
        }

        .confirmation-container h2 {
            color: #343a40;
        }

        .confirmation-message {
            margin-top: 20px;
            font-size: 18px;
        }

        .back-to-home {
            display: block;
            margin-top: 20px;
            text-decoration: none;
            background-color: #343a40;
            color: #fff;
            padding: 10px 20px;
            border-radius: 6px;
            transition: background-color 0.3s;
        }

        .back-to-home:hover {
            background-color: #0ef6cc;
            color: #000000;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <h1>Ardi's Bookstore</h1>
    </header>
    <div class="confirmation-container">
        <h2>Order Confirmation</h2>
        <p class="confirmation-message">Thank you for placing your order with Ardi's Bookstore. Your order has been successfully processed.</p>
        <p class="confirmation-message">Order details have been sent to your registered email address.</p>
        <a href="home.php" class="back-to-home">Back to Home</a>
    </div>
</body>
</html>
