<?php

include 'config.php';
session_start();

if(isset($_POST['submit'])){

$email = mysqli_real_escape_string($conn, $_POST['email']);
$pass = mysqli_real_escape_string($conn, md5($_POST['password']));

$select_users = mysqli_query($conn, "SELECT * FROM `users` WHERE email = '$email' AND password = '$pass'") or die('query failed');

if(mysqli_num_rows($select_users) > 0){

    $row = mysqli_fetch_assoc($select_users);

    if($row['user_type'] == 'admin'){
        $_SESSION['admin_name'] = $row['name'];
        $_SESSION['admin_email'] = $row['email'];
        $_SESSION['admin_id'] = $row['id'];
        header('location:admin_page.php');

    }elseif($row['user_type'] == 'user'){
        $_SESSION['user_name'] = $row['name'];
        $_SESSION['user_email'] = $row['email'];
        $_SESSION['user_id'] = $row['id'];
        header('location:home.php');

    }

}else{
    $message[] = 'incorrect email or password!';
}

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<title>login</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap');
* {
margin: 0;
padding: 0;
box-sizing: border-box;
font-family: 'Poppins', sans-serif;
}

body {
display: flex;
align-items: center;
justify-content: center;
min-height: 100vh;
background: #1b2223;
}

.form-container {
position: relative;
width: 400px;
height: 100%;
background: #fff;
padding: 40px 30px;
border-radius: 10px;
box-shadow: 0 5px 10px rgba(0,0,0,0.2);
}

@media (max-width: 767px) {
.form-container {
max-width: 300px;
padding: 20px 10px;
}
}

.form-container h3 {
text-align: center;
margin-bottom: 40px;
color: #4070f4;
font-family: 'Poppins', sans-serif;
font-size: 40px;
color: #3a4f50;
}

.box {
width: 340px;
padding: 12px 15px;
background: #f5f5f5;
border-radius: 50px;
margin: 8px 0;
font-size: 16px;  
}

.btn {
width: 100%;
background: #3a4f50;
color: #fff;
border: none;
padding: 10px 20px;
font-size: 17px;
cursor: pointer;
border-radius: 50px;
transition: color 0.3s ease-in-out;
}
.btn:hover{
background: #0ef6cc;
}
p {
text-align: center;
margin-top: 15px;
}

p a {
text-decoration: none;
color: #4070f4;
}
.signup-link {
text-decoration: underline;
color: #3a4f50; 
transition: color 0.3s ease-in-out;
}

.signup-link:hover {
color: #0ef6cc; 
}
.social-icons{
    margin: 20px 0;
}
.social-icons {
    height: 20px;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
}

.social-icons a {
    border: 1px solid #ccc;
    border-radius: 50%;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    margin: 0 3px;
    width: 50px;
    height: 50px;
    color: #1b2223;
    margin: auto; 
    font-size: 24px; 
    transition: color 0.3s ease; 
}

.social-icons a:hover {
    color: #0ef6cc;
}


</style>
</head>
<body>
<?php
if(isset($message)){
foreach($message as $message){
    echo '
    <div class="message">
        <span>'.$message.'</span>
        <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
    </div>
    ';
}
}
?>  
<div class="form-container">
<form action="" method="post">
    <h3>WELCOME</h3>
    <input type="email" name="email" placeholder="Enter your email" required class="box">
    <input type="password" name="password" placeholder="Enter your password" required class="box">
    <input type="submit" name="submit" value="Login" class="btn">
    <p>Don't have an account? <a href="register.php" class="signup-link">Sign Up</a></p>
    <div class="social-icons">
        <a href="https://www.gmail.com/" class="icon"><ion-icon name="logo-google"></ion-icon></a>
        <a href="https://www.facebook.com/" class="icon"><ion-icon name="logo-facebook"></ion-icon></a>
        <a href="https://github.com/" class="icon"><ion-icon name="logo-github"></ion-icon></a>
        <a href="https://www.linkedin.com/" class="icon"><ion-icon name="logo-linkedin"></ion-icon></a>
    </div>

</div>
<script>

const toggle = document.querySelector('.form-container');
toggle.addEventListener('click', () => {
toggle.classList.add('active');
})
document.addEventListener('click', e => {
if(e.target !== toggle) {
    toggle.classList.remove('active');
}
})
</script>
</body>
</html>