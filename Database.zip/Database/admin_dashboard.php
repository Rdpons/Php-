<?php
include 'config.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('location: login.php');
    exit();
}

$ordersQuery = "SELECT * FROM orders";
$ordersResult = $conn->query($ordersQuery);

$customersQuery = "SELECT * FROM users WHERE user_type = 'user'";
$customersResult = $conn->query($customersQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>
    <header>
        <h1>Ardi's Bookstore Admin</h1>
    </header>
    <nav>
    </nav>
    <div class="admin-container">
        <h2>Admin Dashboard</h2>
        <div class="orders-container">
            <h3>Orders</h3>
            <?php
            if ($ordersResult && $ordersResult->num_rows > 0) {
                while ($order = $ordersResult->fetch_assoc()) {
                    echo "<div class='order-summary'>";
                    echo "<h4>Order Items</h4>";
             
                    echo "</div>";
                }
            } else {
                echo "<p>No orders found.</p>";
            }
            ?>
        </div>
        <div class="customers-container">
            <h3>Customers</h3>
            <?php
            if ($customersResult && $customersResult->num_rows > 0) {
                while ($customer = $customersResult->fetch_assoc()) {
                    echo "<div class='customer-summary'>";              
                    echo "</div>";
                }
            } else {
                echo "<p>No customers found.</p>";
            }
            ?>
        </div>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>
