<?php
include 'config.php';
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('location: login.php');
    exit();
}

// Fetch all orders
$ordersQuery = "SELECT * FROM orders";
$ordersResult = $conn->query($ordersQuery);

// Fetch all customers
$customersQuery = "SELECT * FROM users WHERE user_type = 'user'";
$customersResult = $conn->query($customersQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Add your CSS styles here -->
</head>
<body>
    <header>
        <h1>Ardi's Bookstore Admin</h1>
    </header>
    <nav>
        <!-- Add your navigation links here -->
    </nav>
    <div class="admin-container">
        <h2>Admin Dashboard</h2>
        <div class="orders-container">
            <h3>Orders</h3>
            <?php
            if ($ordersResult && $ordersResult->num_rows > 0) {
                while ($order = $ordersResult->fetch_assoc()) {
                    echo "<div class='order-summary'>";
                    // Display order information
                    // ...

                    echo "<h4>Order Items</h4>";
                    // Fetch and display order items
                    // ...

                    echo "</div>";
                }
            } else {
                echo "<p>No orders found.</p>";
            }
            ?>
        </div>
        <div class="customers-container">
            <h3>Customers</h3>
            <?php
            if ($customersResult && $customersResult->num_rows > 0) {
                while ($customer = $customersResult->fetch_assoc()) {
                    echo "<div class='customer-summary'>";
                    // Display customer information
                    // ...

                    echo "</div>";
                }
            } else {
                echo "<p>No customers found.</p>";
            }
            ?>
        </div>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>
