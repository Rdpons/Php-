<?php
include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];

if (!isset($user_id)) {
    header('location:login.php');
}

if (isset($_POST['add_to_cart'])) {
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_quantity = $_POST['product_quantity'];

    $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

    if (mysqli_num_rows($check_cart_numbers) > 0) {
        $message[] = 'already added to cart!';
    } else {
        mysqli_query($conn, "INSERT INTO `cart`(user_id, name, price, quantity) VALUES('$user_id', '$product_name', '$product_price', '$product_quantity')") or die('query failed');
        $message[] = 'product added to cart!';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ardi's BookStore</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        header {
            background-color: #1b2223;
            color: white;
            padding: 10px;
            text-align: center;
            width: 100%;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
        }

        nav {
            background-color: #3a4f50;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            position: absolute;
            top: 130px;
            left: -19px;
            z-index: 1;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            display: flex;
        }

        nav li {
            margin-right: 15px;
        }

        nav a {
            text-decoration: none;
            color: white;
            font-weight: bold;
            font-size: 1.2em;
            transition: color 0.3s;
        }

        nav a:hover {
            color: #0ef6cc;
        }

        nav form {
            margin-right: 20px;
        }

        nav input[type="submit"] {
            background-color: #1b2223;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        nav input[type="submit"]:hover {
            background-color: #0ef6cc;
        }

        .content {
            padding: 20px;
            flex: 1;
        }

        .products h1 {
            text-align: center;
            font-size: 50px;
            font-family: "Helvetica Neue", Helvetica;
            color: #333;
        }

        section.products {
            text-align: center;
            padding: 20px;
        }

        .title {
            font-size: 2em;
            margin-bottom: 20px;
            color: #333;
        }

        .box-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .box {
            width: 350px;
            margin: 20px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
        }

        .box:hover {
            transform: scale(1.05);
        }

        .image {
            width: 100%;
            height: 500px;
            object-fit: cover;
            border-radius: 5px;
        }

        .name {
            margin-top: 10px;
            font-weight: bold;
            color: #333;
        }

        .price {
            color: #008000;
            margin-top: 5px;
        }

        .qty {
            margin-top: 10px;
            width: 50px;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .btn {
            margin-top: 10px;
            padding: 8px 16px;
            background-color: #3a4f50;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: transform 0.3s ease-in-out;
        }

        .btn:hover {
            background-color: #0ef6cc;
            color: #f4fefd;
        }

        .empty {
            text-align: center;
            color: #808080;
            margin-top: 20px;
        }

        .load-more {
            margin-top: 2rem;
            text-align: center;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
            color: #333;
            font-size: 20px;
            font-family: 'Arial', sans-serif;
        }

        h1 {
            text-align: center;
            font-size: 50px;
            font-family: "Helvetica Neue", Helvetica;
        }
    </style>
</head>

<body>
    <header>
        <h1>Ardi's BookStore</h1>
    </header>

    <nav>
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="cart.php">Cart</a></li>
        </ul>
        <form method="post" action="logout.php">
            <input type="submit" name="logout" value="Logout">
        </form>
    </nav>
    <section class="products">
        <h1 class="title">Books</h1>
        <div class="box-container">
            <?php
            $books = [
                ['name' => 'Laws of Motion & Attraction', 'price' => 300.00, 'image' => 'img1.jpg'],
                ['name' => 'The Evangelists: Insights from Leaders of the Nations Most Beloved Brands', 'price' => 350.00, 'image' => 'img2.jpg'],
                ['name' => 'The Finishers: Learn First-hand from the Philippine Founders Who Willed Their Startup from Idea to Exit', 'price' => 640.00, 'image' => 'img3.jpg'],
                ['name' => 'Words, Fate & Accidents', 'price' => 600.00, 'image' => 'img4.jpg'],
                ['name' => 'When Turtles Come Home: A Memoir on Life in the Philippines', 'price' => 499.00, 'image' => 'img5.jpg'],
                ['name' => 'Chasing Sunsets: Love & Wonders Anthology', 'price' => 200.00, 'image' => 'img6.jpg'],
                ['name' => 'How to Overcome Financial Stress: Make More Money to be Debt-free', 'price' => 350.00, 'image' => 'img7.jpg'],
                ['name' => 'God Loves Bakla: My Life in the Closet', 'price' => 400.00, 'image' => 'img8.jpg'],
            ];

            foreach ($books as $book) {
            ?>
                <div class="box">
                    <form action="" method="post">
                        <img class="image" src="images/<?php echo $book['image']; ?>" alt="<?php echo $book['name']; ?> Image">
                        <div class="name"><?php echo $book['name']; ?></div>
                        <div class="price">₱<?php echo number_format($book['price'], 2); ?></div>
                        <input type="number" min="1" name="product_quantity" value="1" class="qty">
                        <input type="hidden" name="product_name" value="<?php echo $book['name']; ?>">
                        <input type="hidden" name="product_price" value="<?php echo $book['price']; ?>">
                        <input type="hidden" name="product_image" value="<?php echo $book['image']; ?>">
                        <input type="submit" value="Add to Cart" name="add_to_cart" class="btn">
                    </form>
                </div>
            <?php
            }
            ?>
        </div>
    </section>
    <div class="footer">
        Rhodney Dame N. Ponsica &copy; 2023
    </div>
</body>

</html>
