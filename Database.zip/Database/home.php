<?php
include('config.php');
session_start();

$userImagePath = __DIR__ . "/images/rd.jpg"; // Absolute path

// Check if the file exists
if (!file_exists($userImagePath)) {
    echo "Error: Image file not found at $userImagePath";
    exit();
}

// Read and encode image data with error handling
$userImageData = base64_encode(@file_get_contents($userImagePath));

if ($userImageData === false) {
    echo "Error reading user image: " . error_get_last()['message'];
    exit();
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (isset($_GET['add_to_cart']) && isset($_GET['book_id'])) {
    $bookId = $_GET['book_id'];
    $bookInfoResult = $conn->query("SELECT * FROM books WHERE id = $bookId");

    if ($bookInfoResult && $bookInfo = $bookInfoResult->fetch_assoc()) {
        $cartItem = [
            'id' => $bookInfo['id'],
            'title' => $bookInfo['title'],
            'price' => $bookInfo['price'],
            'image' => "images/{$bookInfo['img']}",
            'isbn' => $bookInfo['isbn'],
            'author' => $bookInfo['author'],
            'genre' => $bookInfo['genre'],
            'type' => $bookInfo['type'],
        ];

        $_SESSION['cart'][] = $cartItem;
    } else {
        echo "Failed to fetch book information. SQL Error: " . $conn->error;
        exit();
    }

    header("Location: home.php");
    exit();
}

$result = $conn->query("SELECT * FROM books");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookstore</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        header {
            background-color: #343a40;
            color: #fff;
            padding: 1rem;
            text-align: center;
            width: 100%;
            margin-bottom: 20px;
            font-size: 50px;
        }

        nav {
            position: absolute;
            top: 200px;
            background-color: #343a40;
            padding: 1rem;
            width: 100%;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        nav li {
            margin: 0 1rem;
        }

        nav li a {
            font-size: 20px;
            font-weight: bold;
            transition: 0.3s;
            color: #fff;
            text-decoration: none;
        }

        nav li a:hover {
            color: #0ef6cc;
            font-weight: bold;
        }

        .user-dropdown {
            position: relative;
            display: flex;
            align-items: center;
            margin-left: auto; 
			position: absolute;
            top: 0px;
			left: 1800px;
	   }

        .user-dropdown img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            cursor: pointer;
        }

        .user-dropdown-content {
            display: none;
            position: absolute;
            background-color: #343a40;
            min-width: 200px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            text-align: right;
            border-radius: 8px;
            padding: 10px;
            top: 40px; 
            right: 0; 
        }

        .user-dropdown:hover .user-dropdown-content {
            display: block;
        }

        .user-dropdown-content a {
            color: #fff;
            padding: 10px;
            text-decoration: none;
            display: block;
            font-size: 16px;
        }

        .user-dropdown-content a:hover {
            background-color: #0ef6cc;
            color: #000000;
        }

        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
        }

        th,
        td {
            border: 1px solid #dee2e6;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #343a40;
            color: #fff;
        }

        .add-to-cart-button {
            background-color: #343a40;
            color: white;
            padding: 10px 16px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
            border: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .add-to-cart-button:hover {
            background-color: #0ef6cc;
            color: #000000;
            font-weight: bold;
        }

        .book-image {
            max-width: 100px;
            max-height: 150px;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <header>
        <h2>Ardi's Bookstore</h2>
    </header>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="cart.php">Cart</a></li>
        </ul>
        <div class="user-dropdown">
            <img src='data:image/jpeg;base64,<?php echo $userImageData; ?>' alt="User Image">
            <div class="user-dropdown-content">
                <a href="#" class="user-info">Rhodney Dame N. Ponsica</a>
                <a href="register.php">Register</a>
                <a href="login.php" class="logout-button">Logout</a>
            </div>
        </div>
    </nav>
    <table>
        <tr>
            <th>ID</th>
            <th>Image</th>
            <th>ISBN</th>
            <th>Title</th>
            <th>Author</th>
            <th>Genre</th>
            <th>Price</th>
            <th>Type</th>
            <th>Quantity</th>
            <th>Action</th>
        </tr>
        <?php
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>{$row['id']}</td>";
            
            // Check if the book image file exists
            $imagePath = "images/{$row['img']}";
            if (file_exists($imagePath)) {
                $imageData = base64_encode(file_get_contents($imagePath));
                echo "<td><img class='book-image' src='data:image/jpeg;base64,{$imageData}' alt='{$row['title']}'></td>";
            } else {
                echo "<td>Image not found</td>";
            }
            
            echo "<td>{$row['isbn']}</td>";
            echo "<td>{$row['title']}</td>";
            echo "<td>{$row['author']}</td>";
            echo "<td>{$row['genre']}</td>";
            echo "<td>₱{$row['price']}</td>";
            echo "<td>{$row['type']}</td>";
            echo "<td>{$row['qty']}</td>";
            echo "<td><a href='home.php?add_to_cart=true&book_id={$row['id']}' class='add-to-cart-button'>Add to Cart</a></td>";
            echo "</tr>";
        }
        $conn->close();
        ?>
    </table>
</body>
</html>