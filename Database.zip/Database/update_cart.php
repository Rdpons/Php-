<?php
session_start();

if (isset($_POST['update_id']) && isset($_POST['new_quantity'])) {
    $updateId = $_POST['update_id'];
    $newQuantity = $_POST['new_quantity'];
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['id'] == $updateId) {
            $item['quantity'] = $newQuantity;
            break;
        }
    }
}

header('Location: cart.php');
exit();
?>
