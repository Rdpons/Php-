<?php
session_start();

if (isset($_POST['update_id']) && isset($_POST['new_quantity'])) {
    $updateId = $_POST['update_id'];
    $newQuantity = $_POST['new_quantity'];

    // Update the quantity of the specified item in the cart
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['id'] == $updateId) {
            $item['quantity'] = $newQuantity;
            break;
        }
    }
}

// Redirect back to the cart page
header('Location: cart.php');
exit();
?>
