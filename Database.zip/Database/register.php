<?php

include 'config.php';

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = mysqli_real_escape_string($conn, md5($_POST['password']));
   $cpass = mysqli_real_escape_string($conn, md5($_POST['cpassword']));
   $user_type = $_POST['user_type'];

   $select_users = mysqli_query($conn, "SELECT * FROM `users` WHERE email = '$email' AND password = '$pass'") or die('query failed');

   if(mysqli_num_rows($select_users) > 0){
      $message[] = 'user already exist!';
   }else{
      if($pass != $cpass){
         $message[] = 'confirm password not matched!';
      }else{
         mysqli_query($conn, "INSERT INTO `users`(name, email, password, user_type) VALUES('$name', '$email', '$cpass', '$user_type')") or die('query failed');
         $message[] = 'registered successfully!';
         header('location:login.php');
      }
   }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Sign Up</title>
<style type="text/css">
body {
         font-family: 'Arial', sans-serif;
         background-color: #1b2223;
         display: flex;
         align-items: center;
         justify-content: center;
         height: 100vh;
         margin: 0;
      }

      .form-container {
         background-color: #fff;
         border-radius: 30px;
         box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
         padding: 30px;
         width: 300px;
         text-align: center;
      }

      form {
         display: flex;
         flex-direction: column;
      }
      h3 {
         color: #333;
         margin-bottom: 20px;
         font-size: 30px;
      }

      .input-group {
         margin-bottom: 15px;
      }

      input,
      select {

         padding: 12px 15px;
         background: #f5f5f5;
         border-radius: 30px;
         width: 100%;
         height: 100%;
         box-sizing: border-box;
         margin-top: 8px;
      }

      .btn {
         background-color: #1b2223;
         color: #fff;
         padding: 10px;
         border: none;
         border-radius: 30px;
         cursor: pointer;
         font-size: 16px;
         transition: background-color 0.3s ease-in-out;
         margin-top: 15px;
      }

      .btn:hover {
         background-color: #0ef6cc;
      }

      p {
         color: #555;
         margin-top: 10px;
      }

      a {
         color: #007bff;
         text-decoration: none;
      }

      .message {
         background-color: #dc3545;
         color: #fff;
         padding: 10px;
         margin-bottom: 10px;
         border-radius: 4px;
         display: flex;
         align-items: center;
         justify-content: center;
         font-size: 14px;
      }

      .message span {
         margin-right: 10px;
      }

      .message i {
         cursor: pointer;
         font-size: 16px;
      }
      .signup-link {
        text-decoration: underline;
        color: #3a4f50; 
        transition: color 0.1s ease-in-out;
      }
        .signup-link:hover {
        color: #0ef6cc; 
      }
</style>
</head>
<body>
<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>  
<div class="form-container">
   <form action="" method="post">
      <h3>Sign Up</h3>
      <input type="text" name="name" placeholder="Enter your name" required class="box">
      <input type="email" name="email" placeholder="Enter your email" required class="box">
      <input type="password" name="password" placeholder=" Enter your password" required class="box">
      <input type="password" name="cpassword" placeholder="Confirm your password" required class="box">
      <select name="user_type" class="box">
         <option value="user">User</option>
         <option value="admin">Admin</option>
      </select>
      <input type="submit" name="submit" value="Sign Up" class="btn">
      <p>Already have an account? <a href="login.php" class="signup-link">Sign In</a></p>
   </form>
</div>
</body>
</html>