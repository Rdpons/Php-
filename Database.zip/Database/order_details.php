<?php
include('config.php');
session_start();

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {

    header("Location: home.php");
    exit();
}
$overallSubtotal = 0;
if (isset($_POST['place_order'])) {
    $userId = $_SESSION['user_id']; 
    $orderDate = date('Y-m-d H:i:s');
    $insertOrderQuery = "INSERT INTO orders (user_id, order_date) VALUES ($userId, '$orderDate')";
    if ($conn->query($insertOrderQuery)) {
        $orderId = $conn->insert_id;
        foreach ($_SESSION['cart'] as $cartItem) {
            $bookId = $cartItem['id'];
            $quantity = $cartItem['qty'];
            $subtotal = $cartItem['price'] * $quantity;
            $overallSubtotal += $subtotal;
            $insertOrderItemQuery = "INSERT INTO order_items (order_id, book_id, quantity, subtotal) VALUES ($orderId, $bookId, $quantity, $subtotal)";
            $conn->query($insertOrderItemQuery);
        }
        $_SESSION['cart'] = [];     
        header("Location: order_confirmation.php?order_id=$orderId");
        exit();
    } else {
        echo "Failed to place the order. SQL Error: " . $conn->error;
    }
}
$userImagePath = "images/rd.jpg"; 
$userImageData = base64_encode(file_get_contents($userImagePath));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        header {
            background-color: #343a40;
            color: #fff;
            padding: 1rem;
            text-align: center;
            width: 100%;
            margin-bottom: 20px;
            font-size: 50px;
        }

        nav {
            position: absolute;
            top: 230px;
            background-color: #343a40;
            padding: 1rem;
            width: 100%;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        nav li {
            margin: 0 1rem;
        }

        nav li a {
            font-size: 20px;
            font-weight: bold;
            transition: 0.3s;
            color: #fff;
            text-decoration: none;
        }

        nav li a:hover {
            color: #0ef6cc;
            font-weight: bold;
        }

        .user-dropdown {
            position: relative;
            display: flex;
            align-items: center;
            margin-left: auto; 
			position: absolute;
            top: 230px;
			left: 1800px;
	   }

        .user-dropdown img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            cursor: pointer;
        }

        .user-dropdown-content {
            display: none;
            position: absolute;
            background-color: #343a40;
            min-width: 200px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            text-align: right;
            border-radius: 8px;
            padding: 10px;
            top: 40px; 
            right: 0; 
        }

        .user-dropdown:hover .user-dropdown-content {
            display: block;
        }

        .user-dropdown-content a {
            color: #fff;
            padding: 10px;
            text-decoration: none;
            display: block;
            font-size: 16px;
        }

        .user-dropdown-content a:hover {
            background-color: #0ef6cc;
            color: #000000;
        }

        table {
            border-collapse: collapse;
            width: 100%; 
            margin: 20px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            border: 1px solid #dee2e6;
            padding: 15px; 
            text-align: center;
        }

        th {
            background-color: #343a40;
            color: #fff;
        }

        .subtotal {
            margin-top: 15px; 
            font-size: 20px; 
            font-weight: bold;
        }

        .cancel-button,
        .place-order-button {
            background-color: #dc3545;
            color: white;
            padding: 15px 20px; 
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 18px; 
            margin-top: 15px; 
            cursor: pointer;
            border: none;
            border-radius: 6px; 
            transition: background-color 0.3s;
        }

        .place-order-button {
            background-color: #343a40;
            color: white;
            padding: 15px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 18px; 
            margin-top: 15px; 
            cursor: pointer;
            border: none;
            border-radius: 6px;
            transition: background-color 0.3s;
        }

        .cancel-button:hover{
			background-color: #c82333;
		}
        .place-order-button:hover {
            background-color: #0ef6cc;
			color: #000000;
			font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <h1>Ardi's Bookstore</h1>
    </header>
	<nav>
        <ul>
            <li><a href="index.php" style="color: #fff; text-decoration: none;">Home</a></li>
            <li><a href="cart.php" style="color: #fff; text-decoration: none;">Cart</a></li> 
        </ul>
    </nav>
    <div>
	<div class="user-dropdown">
            <img src='data:image/jpeg;base64,<?php echo $userImageData; ?>' alt="User Image">
            <div class="user-dropdown-content">
                <a href="#" class="user-info">Rhodney Dame N. Ponsica</a>
                <a href="register.php">Register</a>
                <a href="login.php" class="logout-button">Logout</a>
            </div>
        </div>
        <table>
            <tr>
                <th>Book Image</th>
                <th>Book Title</th>
                <th>Quantity</th>
                <th>Subtotal</th>
            </tr>
            <?php
            foreach ($_SESSION['cart'] as $cartItem) {
                echo "<tr>";
                echo "<td><img src='{$cartItem['image']}' alt='{$cartItem['title']}' style='max-width: 120px; max-height: 180px; border-radius: 8px;'></td>";
                echo "<td>{$cartItem['title']}</td>";
                echo "<td>{$cartItem['qty']}</td>";
                echo "<td>₱" . number_format($cartItem['price'] * $cartItem['qty'], 2) . "</td>";
                echo "</tr>";
                $overallSubtotal += $cartItem['price'] * $cartItem['qty'];
            }
            ?>
        </table>
        <p class="subtotal">Overall Subtotal: ₱<?php echo number_format($overallSubtotal, 2); ?></p>
        <a href="cart.php" class="cancel-button">Cancel</a>
        <form method="post" action="orders.php">
			<button type="submit" name="place_order" class="place-order-button">Place Order</button>
		</form>
    </div>
</body>
</html>