<?php
include('config.php');
session_start();

// Check if the user is authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Now you can safely use $_SESSION['user_id'] in the rest of your script
$userId = $_SESSION['user_id'];

// Assuming you have a table named 'orders' to store order details
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    // Insert order details into the 'orders' table
    $userId = $_SESSION['user_id']; // You should replace this with the actual session variable for user ID
    $orderDate = date('Y-m-d H:i:s'); // Current date and time

    // Assuming you have a column named 'status' to indicate the order status
    $orderStatus = 'Pending'; // You can set the initial status as 'Pending'

    // Insert order details into the 'orders' table
    $insertOrderQuery = "INSERT INTO orders (user_id, order_date, status) VALUES ('$userId', '$orderDate', '$orderStatus')";
    $conn->query($insertOrderQuery);

    // Get the ID of the last inserted order
    $orderId = $conn->insert_id;

    // Insert order items into the 'order_items' table
    foreach ($_SESSION['cart'] as $cartItem) {
        $bookId = $cartItem['id'];
        $quantity = $cartItem['qty'];

        // Assuming you have a table named 'order_items' to store individual items in an order
        $insertOrderItemQuery = "INSERT INTO order_items (order_id, book_id, quantity) VALUES ('$orderId', '$bookId', '$quantity')";
        $conn->query($insertOrderItemQuery);
    }

    // Clear the cart after placing the order
    $_SESSION['cart'] = [];

    // Redirect to a confirmation page or display a success message
    header("Location: order_confirmation.php");
    exit();
}

// ... (your existing PHP code)

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookstore - Orders</title>
    <!-- Add your CSS styles here -->
</head>
<body>
    <header>
        <h1>Ardi's Bookstore</h1>
    </header>
    <nav>
        <!-- Navigation links go here -->
    </nav>
    <div class="order-container">
        <h2>Order Details</h2>
        <?php

        $ordersQuery = "SELECT * FROM orders";
        $ordersResult = $conn->query($ordersQuery);

        if ($ordersResult && $ordersResult->num_rows > 0) {
            while ($order = $ordersResult->fetch_assoc()) {
                $orderId = $order['id'];
                $orderDate = $order['order_date'];
                $orderStatus = $order['status'];

                echo "<div class='order-summary'>";
                echo "<p>Order ID: {$orderId}</p>";
                echo "<p>Order Date: {$orderDate}</p>";
                echo "<p>Status: {$orderStatus}</p>";
                echo "<h3>Order Items</h3>";

                // Fetch order items from the 'order_items' table using a prepared statement
                $orderItemsQuery = "SELECT books.title, order_items.quantity FROM order_items
                                    JOIN books ON order_items.book_id = books.id
                                    WHERE order_items.order_id = ?";

                $stmt = $conn->prepare($orderItemsQuery);
                $stmt->bind_param("i", $orderId);
                $stmt->execute();

                $orderItemsResult = $stmt->get_result();

                if ($orderItemsResult && $orderItemsResult->num_rows > 0) {
                    echo "<ul>";
                    while ($orderItem = $orderItemsResult->fetch_assoc()) {
                        $bookTitle = $orderItem['title'];
                        $quantity = $orderItem['quantity'];

                        echo "<li>{$bookTitle} - Quantity: {$quantity}</li>";
                    }
                    echo "</ul>";
                } else {
                    echo "<p>No items in this order.</p>";
                }

                echo "</div>";
            }
        } else {
            echo "<p>No orders found.</p>";
        }
        ?>
    </div>
</body>
</html>
