<?php
include 'config.php';
session_start();

if (!isset($_SESSION['admin_name'])) {
    header('location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['remove_order'])) {
        $orderId = $_POST['order_id'];

        $deleteOrderItemsQuery = "DELETE FROM order_items WHERE order_id = ?";
        $stmtOrderItems = $conn->prepare($deleteOrderItemsQuery);
        $stmtOrderItems->bind_param('i', $orderId);
        $stmtOrderItems->execute();
        $stmtOrderItems->close();

        $deleteOrderQuery = "DELETE FROM orders WHERE order_id = ?";
        $stmtOrder = $conn->prepare($deleteOrderQuery);
        $stmtOrder->bind_param('i', $orderId);
        $stmtOrder->execute();
        $stmtOrder->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Orders</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        header {
            background-color: #343a40;
            color: #fff;
            padding: 1rem;
            text-align: center;
            width: 100%;
            font-size: 24px;
        }

        nav {
            background-color: #343a40;
            padding: 0.5rem;
            width: 100%;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 15px;
            font-size: 18px;
        }

        .admin-container {
            width: 80%;
            max-width: 1200px;
            margin: 20px auto;
        }

        .admin-container h2 {
            font-size: 28px;
            margin-bottom: 20px;
        }

        .order-summary {
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        .order-summary h3 {
            color: #343a40;
            margin-bottom: 10px;
        }

        .order-items {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .order-item {
            margin-bottom: 10px;
        }

        .remove-order-link {
            background-color: #343a40;
            color: white;
            padding: 10px 16px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
            border: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .remove-order-link:hover {
            background-color: #0ef6cc;
            color: #000000;
            font-weight: bold;
        }

        .back-to-home {
            display: inline-block;
            text-decoration: none;
            background-color: #343a40;
            color: #fff;
            padding: 10px 20px;
            border-radius: 6px;
            transition: background-color 0.3s;
            font-size: 18px;
            margin-top: 20px;
        }

        .back-to-home:hover {
            background-color: #0ef6cc;
            color: #000000;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome, <?php echo $_SESSION['admin_name']; ?>!</h1>
    </header>
    <nav>
        <a href="admin_page.php">Home</a>
        <a href="admin_orders.php">Orders</a>
        <a href="admin_customer.php">Customers</a>
        <a href="admin_book.php">Add Book</a>
        <a href="logout.php">Logout</a>
    </nav>
    <div class="admin-container">
        <h2>Admin Dashboard - Orders</h2>
        <?php
        $ordersQuery = "SELECT * FROM orders";
        $ordersResult = $conn->query($ordersQuery);

        if ($ordersResult && $ordersResult->num_rows > 0) {
            while ($order = $ordersResult->fetch_assoc()) {
                $orderId = $order['order_id'];
                $orderDate = $order['order_date'];
                $orderStatus = $order['status'];

                echo "<div class='order-summary'>";
                echo "<p>Order ID: {$orderId}</p>";
                echo "<p>Order Date: {$orderDate}</p>";
                echo "<p>Status: {$orderStatus}</p>";
                echo "<h3>Order Items</h3>";

                $orderItemsQuery = "SELECT books.title, order_items.quantity FROM order_items
                                    JOIN books ON order_items.book_id = books.id
                                    WHERE order_items.order_id = ?";

                $stmt = $conn->prepare($orderItemsQuery);
                $stmt->bind_param("i", $orderId);
                $stmt->execute();

                $orderItemsResult = $stmt->get_result();

                if ($orderItemsResult && $orderItemsResult->num_rows > 0) {
                    echo "<ul class='order-items'>";
                    while ($orderItem = $orderItemsResult->fetch_assoc()) {
                        $bookTitle = $orderItem['title'];
                        $quantity = $orderItem['quantity'];

                        echo "<li class='order-item'>{$bookTitle} - Quantity: {$quantity}</li>";
                    }
                    echo "</ul>";
                } else {
                    echo "<p>No items in this order.</p>";
                }
                echo "<a href='remove_order.php?remove_order=true&order_id={$orderId}' class='remove-order-link'>Remove Order</a>";
                echo "</div>";
            }
        } else {
            echo "<p>No orders found.</p>";
        }
        ?>
        <a href="#" class="back-to-home">Back to Home</a>
    </div>
</body>
</html>