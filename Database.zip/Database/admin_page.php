<?php

include 'config.php';
session_start();

if(isset($_POST['submit'])){

$email = mysqli_real_escape_string($conn, $_POST['email']);
$pass = mysqli_real_escape_string($conn, md5($_POST['password']));

$select_users = mysqli_query($conn, "SELECT * FROM `users` WHERE email = '$email' AND password = '$pass'") or die('query failed');

if(mysqli_num_rows($select_users) > 0){

    $row = mysqli_fetch_assoc($select_users);

    if($row['user_type'] == 'admin'){
        $_SESSION['admin_name'] = $row['name'];
        $_SESSION['admin_email'] = $row['email'];
        $_SESSION['admin_id'] = $row['id'];
        header('location:admin_page.php');

    }elseif($row['user_type'] == 'user'){
        $_SESSION['user_name'] = $row['name'];
        $_SESSION['user_email'] = $row['email'];
        $_SESSION['user_id'] = $row['id'];
        header('location:home.php');

    }

}else{
    $message[] = 'incorrect email or password!';
}

}
// Fetch all orders
$ordersQuery = "SELECT * FROM orders";
$ordersResult = $conn->query($ordersQuery);

// Fetch all customers
$customersQuery = "SELECT * FROM users WHERE user_type = 'user'";
$customersResult = $conn->query($customersQuery);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Orders</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        header {
            background-color: #343a40;
            color: #fff;
            padding: 1rem;
            text-align: center;
            width: 100%;
            font-size: 24px;
        }

        nav {
            background-color: #343a40;
            padding: 0.5rem;
            width: 100%;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 15px;
            font-size: 18px;
        }

        .admin-container {
            width: 80%;
            max-width: 1200px;
            margin: 20px auto;
        }

        .admin-container h2 {
            font-size: 28px;
            margin-bottom: 20px;
        }

        .orders-container,
        .customers-container,
        .add-book-container {
            background-color: #fff;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .orders-container h3,
        .customers-container h3,
        .add-book-container h3 {
            color: #343a40;
            font-size: 24px;
            margin-bottom: 10px;
        }

        .order-summary,
        .customer-summary {
            margin-bottom: 20px;
        }

        .order-summary p,
        .customer-summary p {
            margin: 0;
            margin-bottom: 5px;
        }

        .order-item,
        .customer-detail {
            margin-bottom: 10px;
        }

        .add-book-container form {
            display: flex;
            flex-direction: column;
        }

        .add-book-container input,
        .add-book-container select,
        .add-book-container button {
            margin-bottom: 10px;
            padding: 10px;
            font-size: 16px;
        }

        .back-to-home {
            display: inline-block;
            text-decoration: none;
            background-color: #343a40;
            color: #fff;
            padding: 10px 20px;
            border-radius: 6px;
            transition: background-color 0.3s;
            font-size: 18px;
        }

        .back-to-home:hover {
            background-color: #0ef6cc;
            color: #000000;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <h1>Ardi's Bookstore Admin</h1>
    </header>
    <nav>
        <a href="admin_page.php">Home</a>
        <a href="admin_orders.php">Orders</a>
        <a href="admin_customer.php">Customers</a>
        <a href="admin_book.php">Add Book</a>
        <a href="logout.php">Logout</a>
    </nav>
	<div class="admin-container">
        <h2>Admin Dashboard - Home</h2>
        <!-- Add your home content here -->
    </div>
</body>
</html>