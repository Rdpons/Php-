<?php
include 'config.php';
session_start();

// Check if the user is not logged in, redirect to login.php
if (!isset($_SESSION['admin_name'])) {
    header('location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_order'])) {
    $orderId = $_POST['order_id'];

    $deleteOrderItemsQuery = "DELETE FROM order_items WHERE order_id = ?";
    $stmtOrderItems = $conn->prepare($deleteOrderItemsQuery);
    $stmtOrderItems->bind_param('i', $orderId);
    $stmtOrderItems->execute();
    $stmtOrderItems->close();

    $deleteOrderQuery = "DELETE FROM orders WHERE order_id = ?";
    $stmtOrder = $conn->prepare($deleteOrderQuery);
    $stmtOrder->bind_param('i', $orderId);
    $stmtOrder->execute();
    $stmtOrder->close();

    // Redirect back to the page displaying orders after removal
    header('location: admin_orders.php');
    exit();
}
?>
