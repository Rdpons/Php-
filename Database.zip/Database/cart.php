<?php
include('config.php');
session_start();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}
if (isset($_GET['add_to_cart']) && isset($_GET['book_id'])) {
    $bookId = $_GET['book_id'];
    $bookInfoResult = $conn->query("SELECT * FROM books WHERE id = $bookId");
    if ($bookInfoResult) {
        $bookInfo = $bookInfoResult->fetch_assoc();

        if ($bookInfo) {
            $cartItem = [
                'id' => $bookInfo['id'],
                'title' => $bookInfo['title'],
                'price' => $bookInfo['price'],
                'image' => "images/{$bookInfo['img']}",
                'isbn' => $bookInfo['isbn'],
                'author' => $bookInfo['author'],
                'genre' => $bookInfo['genre'],
                'type' => $bookInfo['type'],
                'qty' => 1, 
            ];
            $existingKey = array_search($bookId, array_column($_SESSION['cart'], 'id'));
            if ($existingKey !== false) {   
                $_SESSION['cart'][$existingKey]['qty'] += 1;
            } else {
                $_SESSION['cart'][] = $cartItem;
            }
        } else {
            echo "Book not found.";
        }
    } else {
        echo "Failed to fetch book information. SQL Error: " . $conn->error;
    }
    header("Location: cart.php");
    exit();
}
foreach ($_SESSION['cart'] as &$cartItem) {
    if (!isset($cartItem['qty'])) {
        $cartItem['qty'] = 1;
    }
}
if (isset($_GET['remove_from_cart']) && isset($_GET['remove_id'])) {
    $removeId = $_GET['remove_id'];
    $keyToRemove = array_search($removeId, array_column($_SESSION['cart'], 'id'));
    if ($keyToRemove !== false) {
        unset($_SESSION['cart'][$keyToRemove]);
        $_SESSION['cart'] = array_values($_SESSION['cart']);
    } else {
        echo "Item not found in the cart.";
    }
}
if (isset($_POST['update_cart'])) {
    foreach ($_POST['quantity'] as $key => $quantity) {
        $_SESSION['cart'][$key]['qty'] = $quantity;
    }
}
$result = $conn->query("SELECT * FROM books");

if (!$result) {
    die("SQL Error: " . $conn->error);
}

$userImagePath = "images/rd.jpg"; 
$userImageData = base64_encode(file_get_contents($userImagePath));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookstore</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        header {
            background-color: #343a40;
            color: #fff;
            padding: 1rem;
            text-align: center;
            width: 100%;
            margin-bottom: 20px;
            font-size: 50px;
        }

        nav {
            position: absolute;
            top: 250px;
            background-color: #343a40;
            padding: 1rem;
            width: 100%;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        nav li {
            margin: 0 1rem;
        }
		
        nav li a {
            font-size: 20px;
            font-weight: bold;
            transition: 0.3s;
            color: #fff;
            text-decoration: none;
        }

        nav li a:hover {
            color: #0ef6cc;
            font-weight: bold;
        }
		
        .user-dropdown {
            position: relative;
            display: flex;
            align-items: center;
            margin-left: auto; 
            position: absolute;
            top: 0px;
			left: 1800px;
        }

        .user-dropdown img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            cursor: pointer;
        }

        .user-dropdown-content {
            display: none;
            position: absolute;
            background-color: #343a40;
            min-width: 200px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            text-align: right;
            border-radius: 8px;
            padding: 10px;
            top: 40px;
            right: 0; 
        }

        .user-dropdown:hover .user-dropdown-content {
            display: block;
        }

        .user-dropdown-content a {
            color: #fff;
            padding: 10px;
            text-decoration: none;
            display: block;
            font-size: 16px;
        }

        .user-dropdown-content a:hover {
            background-color: #0ef6cc;
            color: #000000;
        }

        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            border: 1px solid #dee2e6;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #343a40;
            color: #fff;
        }

        .add-to-cart-button {
            background-color: #28a745;
            color: white;
            padding: 10px 16px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
            border: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .add-to-cart-button:hover {
            background-color: #218838;
        }

        .book-image {
            max-width: 100px;
            max-height: 150px;
            border-radius: 8px;
        }

        .quantity-input {
            width: 50px;
        }

        .update-cart-button {
            background-color: #343a40;
            color: white;
            padding: 10px 16px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin-top: 10px;
            cursor: pointer;
            border: none;
            border-radius: 4px;
        }

        .update-cart-button:hover {
            background-color: #0ef6cc;
            color: #000000;
            font-weight: bold;
        }

        .place-order-button {
            position: absolute;
            left: 600px;
            background-color: #dc3545;
            color: white;
            padding: 10px 16px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin-top: 10px;
            cursor: pointer;
            border: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .place-order-button:hover {
            background-color: #c82333;
        }

        .remove-from-cart-button {
            background-color: #343a40;
            color: white;
            padding: 10px 16px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
            border: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .remove-from-cart-button:hover {
            background-color: #0ef6cc;
            color: #000000;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <h1>Ardi's Bookstore</h1>
    </header>
    <nav>
        <ul>
            <li><a href="home.php" style="color: #fff; text-decoration: none;">Home</a></li>
            <li><a href="cart.php" style="color: #fff; text-decoration: none;">Cart</a></li> 
        </ul>
        <div class="user-dropdown">
            <img src='data:image/jpeg;base64,<?php echo $userImageData; ?>' alt="User Image">
            <div class="user-dropdown-content">
                <a href="#" class="user-info">Rhodney Dame N. Ponsica</a>
                <a href="register.php">Register</a>
                <a href="login.php" class="logout-button">Logout</a>
            </div>
        </div>
    </nav>
    <div class="cart-container">
        <h2>Shopping Cart</h2>
        <form method="post" action="cart.php">
            <?php
            $overallSubtotal = 0;

            if (is_array($_SESSION['cart']) && !empty($_SESSION['cart'])) {
                echo "<table class='cart-table'>";
                echo "<tr>";
                echo "<th>ID</th>";
                echo "<th>Image</th>";
                echo "<th>ISBN</th>";
                echo "<th>Title</th>";
                echo "<th>Author</th>";
                echo "<th>Genre</th>";
                echo "<th>Price</th>";
                echo "<th>Type</th>";
                echo "<th>Quantity</th>";
                echo "<th>Subtotal</th>";
                echo "<th>Action</th>";
                echo "</tr>";

                foreach ($_SESSION['cart'] as $key => $cartItem) {
                    if (is_array($cartItem) && isset($cartItem['id'], $cartItem['title'], $cartItem['price'], $cartItem['image'])) {

                        $subtotal = $cartItem['price'] * $cartItem['qty'];
                        $overallSubtotal += $subtotal;

                        echo "<tr>";
                        echo "<td>{$cartItem['id']}</td>";
                        echo "<td><img class='book-image' src='{$cartItem['image']}' alt='{$cartItem['title']}'></td>";
                        echo "<td>{$cartItem['isbn']}</td>";
                        echo "<td>{$cartItem['title']}</td>";
                        echo "<td>{$cartItem['author']}</td>";
                        echo "<td>{$cartItem['genre']}</td>";
                        echo "<td>₱{$cartItem['price']}</td>";
                        echo "<td>{$cartItem['type']}</td>";
                        echo "<td><input class='quantity-input' type='number' name='quantity[{$key}]' value='{$cartItem['qty']}' min='1'></td>";
                        echo "<td>₱{$subtotal}</td>";
                        echo "<td><a href='cart.php?remove_from_cart=true&remove_id={$cartItem['id']}' class='remove-from-cart-button'>Remove</a></td>";
                        echo "</tr>";
                    } else {
                        unset($_SESSION['cart'][$key]);  
                        echo "<tr><td colspan='5'>Invalid cart item removed</td></tr>";
                    }
                }
                echo "</table>";
                echo "<p class='subtotal'>Overall Subtotal: ₱{$overallSubtotal}</p>";
                echo "<button type='submit' name='update_cart' class='update-cart-button'>Update Cart</button>";
                echo "<a href='order_details.php' class='place-order-button'>Check Out</a>";
            } else {
                echo "<p>Your cart is empty.</p>";
            }
            ?>
        </form>
    </div>
</body>
</html>
