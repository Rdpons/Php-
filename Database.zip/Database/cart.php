<?php
include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

// Redirect to login page if user is not logged in
if (!isset($user_id)) {
    header('location:login.php');
    exit();
}

// Update cart item quantity
if (isset($_POST['update_cart'])) {
    $cart_id = $_POST['cart_id'];
    $cart_quantity = $_POST['cart_quantity'];

    // Use prepared statements to prevent SQL injection
    $update_query = mysqli_prepare($conn, "UPDATE `cart` SET quantity = ? WHERE id = ?");
    mysqli_stmt_bind_param($update_query, "ii", $cart_quantity, $cart_id);
    mysqli_stmt_execute($update_query);

    $message[] = 'Cart quantity updated!';
}

// Delete a single item from the cart
if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];

    // Use prepared statements to prevent SQL injection
    $delete_query = mysqli_prepare($conn, "DELETE FROM `cart` WHERE id = ?");
    mysqli_stmt_bind_param($delete_query, "i", $delete_id);
    mysqli_stmt_execute($delete_query);

    header('location:cart.php');
    exit();
}

// Delete all items from the cart
if (isset($_GET['delete_all'])) {
    // Use prepared statements to prevent SQL injection
    $delete_all_query = mysqli_prepare($conn, "DELETE FROM `cart` WHERE user_id = ?");
    mysqli_stmt_bind_param($delete_all_query, "i", $user_id);
    mysqli_stmt_execute($delete_all_query);

    header('location:cart.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ardi's BookStore - Shopping Cart</title>
    <!-- Add your CSS and Font Awesome links here -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        /* Add your custom styles for header */

        .heading {
            background-color: #1b2223;
            color: white;
            padding: 10px;
            text-align: center;
        }

        .heading h3 {
            margin: 0;
            font-size: 24px;
        }

        .heading p {
            margin: 0;
            font-size: 14px;
            color: #0ef6cc;
        }

        .shopping-cart {
            text-align: center;
            padding: 20px;
        }

        .title {
            font-size: 36px;
            color: #333;
            margin-bottom: 20px;
        }

        .box-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .box {
            width: 300px;
            margin: 20px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
            position: relative;
        }

        .box:hover {
            transform: scale(1.05);
        }

        .box a {
            position: absolute;
            top: 10px;
            right: 10px;
            color: #ff4040;
            text-decoration: none;
            font-size: 18px;
            cursor: pointer;
        }

        .box img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 5px;
        }

        .name {
            margin-top: 10px;
            font-weight: bold;
            color: #333;
            font-size: 18px;
        }

        .price {
            color: #008000;
            margin-top: 5px;
            font-size: 16px;
        }

        form {
            margin-top: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        input[type="number"] {
            width: 60px;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 3px;
            text-align: center;
        }

        .option-btn {
            background-color: #3a4f50;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .option-btn:hover {
            background-color: #0ef6cc;
        }

        .sub-total {
            margin-top: 10px;
            font-size: 16px;
        }

        .delete-btn {
            background-color: #ff4040;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .delete-btn:hover {
            background-color: #ff6666;
        }

        .cart-total {
            margin-top: 20px;
            text-align: center;
        }

        .cart-total p {
            font-size: 20px;
            margin: 10px 0;
        }

        .cart-total span {
            font-weight: bold;
        }

        .flex {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }

        .btn {
            background-color: #3a4f50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .btn:hover {
            background-color: #0ef6cc;
        }

        .disabled {
            pointer-events: none;
            background-color: #ccc;
            color: #666;
        }

    </style>
</head>

<body>
    <div class="heading">
        <h3>Shopping Cart</h3>
        <p><a href="home.php">Home</a> / Cart</p>
    </div>

    <section class="shopping-cart">

        <h1 class="title">Products Added</h1>

        <div class="box-container">
            <?php
            $grand_total = 0;
            $select_cart_query = mysqli_prepare($conn, "SELECT * FROM `cart` WHERE user_id = ?");
            mysqli_stmt_bind_param($select_cart_query, "i", $user_id);
            mysqli_stmt_execute($select_cart_query);
            $result = mysqli_stmt_get_result($select_cart_query);

            if (mysqli_num_rows($result) > 0) {
                while ($fetch_cart = mysqli_fetch_assoc($result)) {
            ?>
            <div class="box">
                <a href="cart.php?delete=<?php echo $fetch_cart['id']; ?>" class="fas fa-times"
                    onclick="return confirm('Delete this from cart?');"></a>
                <img src="uploaded_img/<?php echo $fetch_cart['image']; ?>" alt="">
                <div class="name"><?php echo $fetch_cart['name']; ?></div>
                <div class="price">$<?php echo $fetch_cart['price']; ?>/-</div>
                <form action="" method="post">
                    <input type="hidden" name="cart_id" value="<?php echo $fetch_cart['id']; ?>">
                    <input type="number" min="1" name="cart_quantity" value="<?php echo $fetch_cart['quantity']; ?>">
                    <input type="submit" name="update_cart" value="Update" class="option-btn">
                </form>
                <div class="sub-total">Subtotal: <span>$<?php echo $sub_total = ($fetch_cart['quantity'] * $fetch_cart['price']); ?>/-</span>
                </div>
            </div>
            <?php
                    $grand_total += $sub_total;
                }
            } else {
                echo '<p class="empty">Your cart is empty</p>';
            }
            ?>
        </div>
        <div style="margin-top: 2rem; text-align:center;">
            <a href="cart.php?delete_all" class="delete-btn <?php echo ($grand_total > 1) ? '' : 'disabled'; ?>"
                onclick="return confirm('Delete all from cart?');">Delete All</a>
        </div>
        <div class="cart-total">
            <p>Grand Total: <span>$<?php echo $grand_total; ?>/-</span></p>
            <div class="flex">
                <a href="shop.php" class="option-btn">Continue Shopping</a>
                <a href="checkout.php" class="btn <?php echo ($grand_total > 1) ? '' : 'disabled'; ?>">Proceed to
                    Checkout</a>
            </div>
        </div>
    </section>
</body>
</html>