<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $time = isset($data['timeIn']) ? $data['timeIn'] : $data['timeOut'];

    $logFile = 'time_log.txt';
    $logEntry = "Time: $time\n";
    file_put_contents($logFile, $logEntry, FILE_APPEND);

    echo json_encode(['status' => 'success', 'message' => 'Time recorded.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}

?>