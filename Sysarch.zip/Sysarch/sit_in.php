<?php
include('config.php'); 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    $query = "UPDATE users SET remaining_session = remaining_session - 1 WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id); 
    $stmt->execute();
    if ($stmt->error) {
        echo "Error: " . $stmt->error;
    } else {
        echo "User's remaining session decremented.";
    }
} else {
    echo "No user ID provided.";
}
?>
