<?php
session_start();

if (isset($_POST['sit_in_button'])) {
    $_SESSION['sit_in_clicked'] = true;

    $_SESSION['user_id'] = $_POST['user_id'];
    echo "Form submitted and session set."; 
    header("Location: viewrecord.php");
    exit;
}
?>