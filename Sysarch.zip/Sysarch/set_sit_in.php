<?php
session_start();

// Include your database connection script
include("config.php");

if (isset($_POST['sit_in_button'])) {
    // Assuming 'idno' is the unique identifier for the user
    $user_id = $_POST['user_id'];
    $time_in = $_POST['time_in'];

    // Prepare an SQL statement to update the time_in value
    $stmt = $conn->prepare("UPDATE users SET time_in = ? WHERE idno = ?");
    $stmt->bind_param("ss", $time_in, $user_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Time in updated successfully.";
    } else {
        echo "Error updating time in: " . $stmt->error;
    }

    // Redirect to viewrecord.php after processing
    header("Location: viewrecord.php");
    exit;
}
?>