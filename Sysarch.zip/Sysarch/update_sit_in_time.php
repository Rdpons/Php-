<?php
include('config.php');

if (isset($_POST['userId'])) {
    $userId = $_POST['userId'];

    $sitInTime = 30 * 60; 
    $currentTime = time();
    $endTime = $currentTime + $sitInTime;
    $endTimeFormatted = date('Y-m-d H:i:s', $endTime);

    $sql = "UPDATE users SET sitInEndTime = ? WHERE idno = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $endTimeFormatted, $userId);

    if ($stmt->execute()) {
        echo "Update successful";
    } else {
        echo "Error updating record: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
