<?php
include('config.php');

if (isset($_POST['userId'])) {
    $userId = $_POST['userId'];

    $newRemainingSession = 1740; 
    $sql = "UPDATE users SET session_status = 'timeout', remaining_session = ? WHERE idno = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $newRemainingSession, $userId);

    if ($stmt->execute()) {
        echo "User timed out successfully. Remaining session set to 29 minutes.";
    } else {
        echo "Error timing out user: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
