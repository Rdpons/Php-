<?php
include('config.php');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'config.php'; // Ensure this file contains your database connection details

    // Retrieve the submitted form data
    $studentId = $_POST['id'];
    $remainingSession = $_POST['remainingSession'];

    // Prepare the SQL statement to update the user's remaining session
    $sql = "UPDATE users SET remaining_session = ? WHERE idno = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $remainingSession, $studentId);

    if ($stmt->execute()) {
        // Redirect to admin.php after successful update
        header("Location: admin.php");
        exit; // Ensure the script stops executing after the redirect
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
