<?php
include('config.php');
$_SESSION['sit_in_clicked'] = true;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $idno = $_POST['user_id'];
    $purpose = $_POST['purpose'];
    $lab = $_POST['lab'];

    $query = "UPDATE users SET purpose = ?, lab = ? WHERE idno = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssi", $purpose, $lab, $idno);

    if ($stmt->execute()) {
        header("Location: viewrecord.php?search=$idno");
        exit;
    } else {
        echo "Error updating record: " . $stmt->error;
    }
}
?>
