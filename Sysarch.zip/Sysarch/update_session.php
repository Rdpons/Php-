<?php
include('config.php');

if (isset($_POST['idno'])) {
    $idno = $_POST['idno'];
    $sql = "UPDATE users SET remaining_session = remaining_session - 1 WHERE idno = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $idno);
    if ($stmt->execute()) {
        $sql = "SELECT remaining_session FROM users WHERE idno = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $idno);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo $row['remaining_session']; 
        }
    } else {
        echo "Error updating session";
    }
}

$conn->close();
?>
